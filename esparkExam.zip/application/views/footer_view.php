</div><div id="footer">
  <p> FLAT - Responsive Admin Template <span class="font-grey-4">|</span> <a href="#">Contact</a> <span class="font-grey-4">|</span> <a href="#">Imprint</a> </p>
  <a href="#" class="gototop"><i class="icon-arrow-up"></i></a> </div>
</body>
</html>