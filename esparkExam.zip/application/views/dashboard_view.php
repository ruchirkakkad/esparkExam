<div id="main">
    <div class="container-fluid">
        <div class="page-header">
            <div class="pull-left">
                <h1>Dashboard</h1>
            </div>
            <div class="pull-right">
                <ul class="stats">
                    <li class='satgreen'> <i class="icon-money"></i>
                        <div class="details"> <span class="big">$324,12</span> <span>Balance</span> </div>
                    </li>
                    <li class='darkblue'> <i class="icon-user"></i>
                        <div class="details"> <span class="big">324,12</span> <span>User</span> </div>
                    </li>
                    <li class='lightred'> <i class="icon-calendar"></i>
                        <div class="details"> <span class="big">February 22, 2013</span> <span>Wednesday, 13:56</span> </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="breadcrumbs">
            <ul>
                <li> <a href="more-login.html">Home</a> <i class="icon-angle-right"></i> </li>
                <li> <a href="index.html">Dashboard</a> </li>
            </ul>
            <div class="close-bread"> <a href="#"><i class="icon-remove"></i></a> </div>
        </div>
    </div>
</div>